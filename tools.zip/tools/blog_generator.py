"""
blog_generator.py - Blog post HTML generation and blog.html update
"""

import json
import re
import shutil
from datetime import date
from pathlib import Path

from bs4 import BeautifulSoup
from jinja2 import Environment, FileSystemLoader

MONTHS_SR = {
    1: "januar", 2: "februar", 3: "mart", 4: "april",
    5: "maj", 6: "jun", 7: "jul", 8: "avgust",
    9: "septembar", 10: "oktobar", 11: "novembar", 12: "decembar"
}

# Map category_slug → (service_page_url, cta_button_text, cta_heading, cta_body)
CATEGORY_CTA_MAP = {
    "trudnice": (
        "/fotografisanje-trudnica.html",
        "Pogledajte cene za trudnice",
        "Želite trudničke fotografije za pamćenje?",
        "Javite mi se na vreme da zakažemo termin u idealnom periodu vaše trudnoće. Neka ovo bude jedna od najlepših uspomena."
    ),
    "bebe": (
        "/fotografisanje-beba.html",
        "Cene fotografisanja beba",
        "Zakažite sesiju za vašu bebu",
        "Javite mi se na vreme, idealno još dok ste u trudnoći, da rezervišemo termin. Dolazim u Pančevo, Beograd, Novi Sad i celu Srbiju."
    ),
    "porodica": (
        "/porodicno-fotografisanje.html",
        "Pogledajte cene",
        "Zakažite porodično fotografisanje",
        "Neka vaša porodica ima fotografije koje ćete čuvati zauvek. Dolazim na vašu adresu u Pančevu, Beogradu, Novom Sadu i celoj Srbiji."
    ),
    "vencanja": (
        "/fotografisanje-vencanja.html",
        "Cene venčanog fotografisanja",
        "Sačuvajte uspomene sa vašeg venčanja",
        "Javite mi se i razgovarajmo o vašem najvažnijem danu. Rezervišite termin na vreme."
    ),
    "krstenja": (
        "/fotografisanje-krstenja.html",
        "Pogledajte cene",
        "Zakažite fotografisanje krštenja",
        "Neka fotografije krštenja budu uspomena za ceo život. Javite mi se i zakažemo termin."
    ),
    "rodjendani": (
        "/fotografisanje-rodjendana.html",
        "Pogledajte cene",
        "Zakažite fotografisanje rođendana",
        "Neka svaka sveća bude sačuvana u lepoj fotografiji. Javite mi se i zakažemo termin."
    ),
    "biznis": (
        "/biznis-portreti.html",
        "Pogledajte cene",
        "Zakažite biznis portrete",
        "Profesionalne fotografije koje ostavljaju utisak. Javite mi se i zakažemo sesiju."
    ),
    "proizvodi": (
        "/fotografisanje-proizvoda.html",
        "Pogledajte cene",
        "Zakažite fotografisanje proizvoda",
        "Fotografije koje prodaju. Javite mi se i zakažemo sesiju za vaše proizvode."
    ),
    "modeling": (
        "/modeling-fotografisanje.html",
        "Pogledajte cene",
        "Zakažite modeling sesiju",
        "Izgradite portfolio koji otvara vrata. Javite mi se i zakažemo vašu modeling sesiju."
    ),
    "saveti": (
        "/kontakt.html",
        "Zakažite termin",
        "Rezervišite vašu sesiju",
        "Dolazim u Pančevo, Beograd, Novi Sad i celu Srbiju. Zakažite termin i neka fotografije govore."
    ),
}

DEFAULT_CTA = (
    "/kontakt.html",
    "Zakažite termin",
    "Rezervišite vašu sesiju",
    "Dolazim u Pančevo, Beograd, Novi Sad i celu Srbiju. Zakažite termin i neka fotografije govore."
)


def format_date_sr(date_obj: date) -> str:
    """Return Serbian date string: '18. mart 2026.'"""
    return f"{date_obj.day}. {MONTHS_SR[date_obj.month]} {date_obj.year}."


def count_words_in_html(html: str) -> int:
    """Count words in HTML content (strip tags first)."""
    soup = BeautifulSoup(html, 'html.parser')
    text = soup.get_text(separator=' ')
    words = [w for w in text.split() if w.strip()]
    return len(words)


def extract_excerpt(body_html: str, max_chars: int = 160) -> str:
    """Extract plain text excerpt from body HTML."""
    soup = BeautifulSoup(body_html, 'html.parser')
    first_p = soup.find('p')
    if first_p:
        text = first_p.get_text(strip=True)
        if len(text) > max_chars:
            text = text[:max_chars].rsplit(' ', 1)[0] + '...'
        return text
    return ""


def inject_inline_images(body_html: str, inline_images: list) -> str:
    """
    Inject inline <img> tags into body_html at natural paragraph breaks.
    Inserts after the 2nd </p> and after the 4th </p>.
    """
    if not inline_images:
        return body_html

    def make_img_tag(filename: str) -> str:
        return (
            f'\n                <img\n'
            f'                    src="../images/{filename}"\n'
            f'                    alt=""\n'
            f'                    loading="lazy"\n'
            f'                    decoding="async"\n'
            f'                >\n'
        )

    # Split on </p> to find injection points
    parts = body_html.split('</p>')
    total = len(parts)

    # Target positions (0-indexed: after which </p>)
    targets = {}
    if inline_images:
        pos1 = max(1, total // 3)
        targets[pos1] = inline_images[0]
    if len(inline_images) > 1:
        pos2 = max(pos1 + 1, 2 * total // 3)
        targets[pos2] = inline_images[1]

    result = []
    for i, part in enumerate(parts):
        result.append(part)
        if i < len(parts) - 1:
            result.append('</p>')
            if i in targets:
                result.append(make_img_tag(targets[i]))

    return ''.join(result)


def get_related_posts(blog_dir: str, exclude_slug: str, count: int = 2) -> list:
    """
    Scan existing blog posts and return metadata for related posts display.
    Sorted by file modification time (newest first).
    """
    blog_path = Path(blog_dir)
    posts = []

    html_files = sorted(
        blog_path.glob('*.html'),
        key=lambda f: f.stat().st_mtime,
        reverse=True
    )

    for post_file in html_files:
        if post_file.stem == exclude_slug:
            continue
        try:
            content = post_file.read_text(encoding='utf-8')
            soup = BeautifulSoup(content, 'html.parser')

            # Title
            h1 = soup.find('h1', class_='blog-post-hero__title')
            title = h1.get_text(strip=True) if h1 else post_file.stem.replace('-', ' ').title()

            # Date
            time_tag = soup.find('time')
            date_display = time_tag.get_text(strip=True) if time_tag else ''
            datetime_attr = time_tag.get('datetime', '') if time_tag else ''

            # Reading time
            reading_time_text = '3 min'
            if time_tag and time_tag.parent:
                for span in time_tag.parent.find_all('span'):
                    if 'min' in span.get_text():
                        reading_time_text = span.get_text(strip=True)
                        break

            # Hero image
            hero_img = soup.find('img', class_='blog-post-hero__bg-img')
            img_filename = ''
            if hero_img:
                src = hero_img.get('src', '')
                img_filename = re.sub(r'^(\.\./)?images/', '', src)

            posts.append({
                'url': f'/blog/{post_file.stem}.html',
                'image': img_filename,
                'title': title,
                'date_display': date_display,
                'datetime': datetime_attr,
                'reading_time': reading_time_text,
            })

            if len(posts) >= count:
                break
        except Exception:
            continue

    return posts


def build_blogposting_json(data: dict, hero_image: str, today: date, word_count: int) -> str:
    schema = {
        "@context": "https://schema.org",
        "@type": "BlogPosting",
        "mainEntityOfPage": {
            "@type": "WebPage",
            "@id": f"https://angelicphoto.rs/blog/{data['slug']}.html"
        },
        "headline": data['title'],
        "description": data['meta_description'],
        "image": f"https://angelicphoto.rs/images/{hero_image}",
        "datePublished": today.strftime('%Y-%m-%d'),
        "dateModified": today.strftime('%Y-%m-%d'),
        "author": {
            "@type": "Person",
            "name": "Anđela",
            "url": "https://angelicphoto.rs/o-meni.html"
        },
        "publisher": {
            "@type": "Organization",
            "name": "Angelic Photo",
            "logo": {
                "@type": "ImageObject",
                "url": "https://angelicphoto.rs/images/logo.jpg"
            }
        },
        "articleSection": data['category'],
        "wordCount": word_count,
        "inLanguage": "sr"
    }
    return json.dumps(schema, ensure_ascii=False, indent=4)


def build_breadcrumb_json(data: dict) -> str:
    schema = {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": [
            {"@type": "ListItem", "position": 1, "name": "Početna", "item": "https://angelicphoto.rs/"},
            {"@type": "ListItem", "position": 2, "name": "Blog", "item": "https://angelicphoto.rs/blog.html"},
            {"@type": "ListItem", "position": 3, "name": data['title'],
             "item": f"https://angelicphoto.rs/blog/{data['slug']}.html"}
        ]
    }
    return json.dumps(schema, ensure_ascii=False, indent=4)


def build_faq_json(faq: list) -> str:
    schema = {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            {
                "@type": "Question",
                "name": item['question'],
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": item['answer']
                }
            }
            for item in faq
        ]
    }
    return json.dumps(schema, ensure_ascii=False, indent=4)


def generate_keywords(topic: str, category: str, category_slug: str) -> str:
    """Generate keywords meta tag content."""
    base_keywords = [
        topic.lower(),
        f"fotografisanje {category_slug}",
        f"fotograf {category_slug} Pančevo",
        f"fotograf {category_slug} Beograd",
        category.lower(),
        "Angelic Photo",
        "fotograf Pančevo",
    ]
    return ", ".join(base_keywords)


def render_blog_post(data: dict, hero_image: str, inline_images: list,
                     related_posts: list, today: date, repo_root: str) -> str:
    """
    Render the complete blog post HTML using Jinja2 template.
    Returns the rendered HTML string.
    """
    tools_dir = Path(repo_root) / 'tools'
    env = Environment(
        loader=FileSystemLoader(str(tools_dir / 'templates')),
        autoescape=False  # We manage escaping manually
    )
    template = env.get_template('blog_post.html')

    body_with_images = inject_inline_images(data['body_html'], inline_images)
    word_count = count_words_in_html(body_with_images)
    excerpt = extract_excerpt(data['body_html'])

    cta = CATEGORY_CTA_MAP.get(data['category_slug'], DEFAULT_CTA)

    ctx = {
        'meta_title': data['meta_title'],
        'meta_description': data['meta_description'],
        'keywords': generate_keywords(data.get('title', ''), data['category'], data['category_slug']),
        'slug': data['slug'],
        'title': data['title'],
        'category': data['category'],
        'category_slug': data['category_slug'],
        'hero_image': hero_image,
        'hero_alt': data['title'],
        'date_iso': today.strftime('%Y-%m-%d'),
        'date_display': format_date_sr(today),
        'reading_time': data.get('reading_time', 4),
        'word_count': word_count,
        'body_html': body_with_images,
        'blockquote': data.get('blockquote', ''),
        'faq': data.get('faq', []),
        'related_posts': related_posts,
        'cta_service_url': cta[0],
        'cta_service_text': cta[1],
        'cta_heading': cta[2],
        'cta_text': cta[3],
        # Pre-rendered JSON-LD
        'blogposting_json': build_blogposting_json(data, hero_image, today, word_count),
        'breadcrumb_json': build_breadcrumb_json(data),
        'faq_json': build_faq_json(data.get('faq', [])),
    }

    return template.render(**ctx)


def save_blog_post(html: str, slug: str, blog_dir: str) -> Path:
    """Save rendered HTML to blog/ folder atomically."""
    blog_path = Path(blog_dir)
    blog_path.mkdir(parents=True, exist_ok=True)

    out_path = blog_path / f'{slug}.html'
    tmp_path = blog_path / f'{slug}.html.tmp'

    tmp_path.write_text(html, encoding='utf-8')
    tmp_path.rename(out_path)
    return out_path


def update_blog_html(blog_html_path: str, new_post_data: dict, hero_image: str,
                     today: date, excerpt: str):
    """
    Update blog.html: insert new card into grid and update featured if newer.
    Creates a .bak backup before modifying.
    """
    blog_html = Path(blog_html_path)
    if not blog_html.exists():
        print(f"      Warning: {blog_html_path} not found, skipping update.")
        return

    # Backup
    shutil.copy2(blog_html_path, blog_html_path + '.bak')

    content = blog_html.read_text(encoding='utf-8')
    soup = BeautifulSoup(content, 'html.parser')

    date_iso = today.strftime('%Y-%m-%d')
    date_display = format_date_sr(today)
    reading_time = new_post_data.get('reading_time', 4)
    slug = new_post_data['slug']
    title = new_post_data['title']
    category = new_post_data['category']
    category_slug = new_post_data['category_slug']
    meta_description = new_post_data.get('meta_description', excerpt)

    # --- Update Schema.org blogPost array ---
    for script in soup.find_all('script', {'type': 'application/ld+json'}):
        try:
            schema = json.loads(script.string)
            if schema.get('@type') == 'Blog' and 'blogPost' in schema:
                new_entry = {
                    "@type": "BlogPosting",
                    "headline": title,
                    "description": meta_description,
                    "url": f"https://angelicphoto.rs/blog/{slug}.html",
                    "datePublished": date_iso,
                    "author": {"@type": "Person", "name": "Anđela"},
                    "image": f"https://angelicphoto.rs/images/{hero_image}"
                }
                schema['blogPost'].insert(0, new_entry)
                script.string = json.dumps(schema, ensure_ascii=False, indent=12)
                break
        except (json.JSONDecodeError, AttributeError, TypeError):
            continue

    # --- Check featured post date ---
    featured_section = soup.find('section', class_='blog-featured')
    should_rotate = False
    featured_article = None

    if featured_section:
        featured_article = featured_section.find('article', class_='blog-featured-card')
        if featured_article:
            feat_time = featured_article.find('time')
            if feat_time:
                feat_datetime = feat_time.get('datetime', '')
                try:
                    from datetime import datetime as dt
                    feat_date = dt.strptime(feat_datetime, '%Y-%m-%d').date()
                    if today > feat_date:
                        should_rotate = True
                except (ValueError, TypeError):
                    should_rotate = True  # assume new is newer if we can't parse

    # --- Build new featured card HTML ---
    new_featured_html = f'''<article class="blog-featured-card" data-category="{category_slug}">
                    <a href="/blog/{slug}.html" class="blog-featured-card__link">
                        <div class="blog-featured-card__img-wrap">
                            <img
                                src="images/{hero_image}"
                                alt="{title}"
                                class="blog-featured-card__img"
                                loading="eager"
                                decoding="async"
                            >
                        </div>
                        <div class="blog-featured-card__body">
                            <span class="blog-card__category">{category}</span>
                            <h2 class="blog-featured-card__title">{title}</h2>
                            <p class="blog-featured-card__excerpt">{excerpt}</p>
                            <div class="blog-featured-card__meta">
                                <time datetime="{date_iso}">{date_display}</time>
                                <span>·</span>
                                <span>{reading_time} min čitanja</span>
                            </div>
                            <span class="blog-card__read-more">Pročitaj više →</span>
                        </div>
                    </a>
                </article>'''

    # --- Build new regular card HTML ---
    new_card_html = f'''<article class="blog-card" data-category="{category_slug}">
                        <a href="/blog/{slug}.html" class="blog-card__link">
                            <div class="blog-card__img-wrap">
                                <img
                                    src="images/{hero_image}"
                                    alt="{title}"
                                    class="blog-card__img"
                                    loading="lazy"
                                    decoding="async"
                                >
                            </div>
                            <div class="blog-card__body">
                                <span class="blog-card__category">{category}</span>
                                <h3 class="blog-card__title">{title}</h3>
                                <p class="blog-card__excerpt">{excerpt}</p>
                                <div class="blog-card__meta">
                                    <time datetime="{date_iso}">{date_display}</time>
                                    <span>·</span>
                                    <span>{reading_time} min čitanja</span>
                                </div>
                                <span class="blog-card__read-more">Pročitaj više →</span>
                            </div>
                        </a>
                    </article>'''

    grid = soup.find('div', class_='blog-listing__grid')

    if should_rotate and featured_article:
        # Build demoted card from old featured
        feat_link = featured_article.find('a', class_='blog-featured-card__link')
        feat_href = feat_link.get('href', '#') if feat_link else '#'
        feat_img_tag = featured_article.find('img', class_='blog-featured-card__img')
        feat_img_src = ''
        if feat_img_tag:
            src = feat_img_tag.get('src', '')
            feat_img_src = re.sub(r'^images/', '', src)
        feat_h2 = featured_article.find('h2', class_='blog-featured-card__title')
        feat_title = feat_h2.get_text(strip=True) if feat_h2 else ''
        feat_p = featured_article.find('p', class_='blog-featured-card__excerpt')
        feat_excerpt = feat_p.get_text(strip=True) if feat_p else ''
        feat_cat_span = featured_article.find('span', class_='blog-card__category')
        feat_cat = feat_cat_span.get_text(strip=True) if feat_cat_span else ''
        feat_cat_slug = featured_article.get('data-category', '')
        feat_time_tag = featured_article.find('time')
        feat_time_display = feat_time_tag.get_text(strip=True) if feat_time_tag else ''
        feat_datetime_val = feat_time_tag.get('datetime', '') if feat_time_tag else ''
        feat_reading = '3 min čitanja'
        feat_meta = featured_article.find('div', class_='blog-featured-card__meta')
        if feat_meta:
            for sp in feat_meta.find_all('span'):
                if 'min' in sp.get_text():
                    feat_reading = sp.get_text(strip=True)
                    break

        demoted_html = f'''<article class="blog-card" data-category="{feat_cat_slug}">
                        <a href="{feat_href}" class="blog-card__link">
                            <div class="blog-card__img-wrap">
                                <img
                                    src="images/{feat_img_src}"
                                    alt="{feat_title}"
                                    class="blog-card__img"
                                    loading="lazy"
                                    decoding="async"
                                >
                            </div>
                            <div class="blog-card__body">
                                <span class="blog-card__category">{feat_cat}</span>
                                <h3 class="blog-card__title">{feat_title}</h3>
                                <p class="blog-card__excerpt">{feat_excerpt}</p>
                                <div class="blog-card__meta">
                                    <time datetime="{feat_datetime_val}">{feat_time_display}</time>
                                    <span>·</span>
                                    <span>{feat_reading}</span>
                                </div>
                                <span class="blog-card__read-more">Pročitaj više →</span>
                            </div>
                        </a>
                    </article>'''

        # Replace featured article
        new_feat_tag = BeautifulSoup(new_featured_html, 'html.parser')
        featured_article.replace_with(new_feat_tag)

        # Add demoted card to grid
        if grid:
            demoted_tag = BeautifulSoup(demoted_html, 'html.parser')
            grid.insert(0, demoted_tag)
    else:
        # Just add new card to the grid
        if grid:
            new_card_tag = BeautifulSoup(new_card_html, 'html.parser')
            grid.insert(0, new_card_tag)

    # Write back
    blog_html.write_text(str(soup), encoding='utf-8')
    print(f"      Updated: blog.html (new card added{', featured post rotated' if should_rotate else ''})")
