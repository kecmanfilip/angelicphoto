#!/usr/bin/env python3
"""
app.py - Web GUI for Angelic Photo blog + carousel generator

Run:   python tools/app.py
Open:  http://localhost:8000
"""

import asyncio
import os
import sys
import threading
from datetime import date
from pathlib import Path
from types import SimpleNamespace

TOOLS_DIR = Path(__file__).parent
REPO_ROOT = TOOLS_DIR.parent
sys.path.insert(0, str(TOOLS_DIR))

# Load .env file from tools/ if it exists (ANTHROPIC_API_KEY=sk-...)
_env_file = TOOLS_DIR / ".env"
if _env_file.exists():
    for _line in _env_file.read_text().splitlines():
        _line = _line.strip()
        if _line and not _line.startswith("#") and "=" in _line:
            _k, _v = _line.split("=", 1)
            os.environ.setdefault(_k.strip(), _v.strip())

try:
    from fastapi import FastAPI
    from fastapi.responses import HTMLResponse, StreamingResponse, FileResponse, JSONResponse
    from pydantic import BaseModel
    import uvicorn
except ImportError:
    print("ERROR: pip install fastapi uvicorn")
    sys.exit(1)

app = FastAPI()

# Only one generation at a time (single-user tool)
_generation_lock = threading.Lock()

# job_id -> asyncio.Queue of log lines
_jobs: dict = {}

# Last generation result (slug, generated_blog)
_last_result: dict = {"slug": None, "generated_blog": False}


# ---------------------------------------------------------------------------
# Request model
# ---------------------------------------------------------------------------

class GenerateRequest(BaseModel):
    topic: str
    generate_blog: bool = True
    generate_carousel: bool = True
    api_key: str = ""


class ApiKeyRequest(BaseModel):
    api_key: str


# ---------------------------------------------------------------------------
# Stdout capture
# ---------------------------------------------------------------------------

class _QueueWriter:
    """Tees print() output to both the real stdout and an asyncio Queue."""

    def __init__(self, queue: asyncio.Queue, loop: asyncio.AbstractEventLoop, original):
        self._q = queue
        self._loop = loop
        self._orig = original
        self._buf = ""

    def write(self, text: str):
        self._orig.write(text)
        self._buf += text
        while "\n" in self._buf:
            line, self._buf = self._buf.split("\n", 1)
            stripped = line.strip()
            if stripped:
                asyncio.run_coroutine_threadsafe(self._q.put(stripped), self._loop)

    def flush(self):
        self._orig.flush()


# ---------------------------------------------------------------------------
# Generation thread
# ---------------------------------------------------------------------------

def _generation_thread(topic: str, generate_blog: bool, generate_carousel: bool,
                        queue: asyncio.Queue, loop: asyncio.AbstractEventLoop,
                        api_key: str = ""):
    with _generation_lock:
        old_stdout = sys.stdout
        sys.stdout = _QueueWriter(queue, loop, old_stdout)

        # Inject API key into env for this process if provided via GUI
        if api_key:
            os.environ["ANTHROPIC_API_KEY"] = api_key

        def done(ok=True):
            if ok and generate_blog:
                # Find most recently modified blog post to extract slug
                blog_dir_path = REPO_ROOT / "blog"
                if blog_dir_path.exists():
                    posts = [f for f in blog_dir_path.glob("*.html") if f.stem != "index"]
                    if posts:
                        newest = max(posts, key=lambda f: f.stat().st_mtime)
                        _last_result["slug"] = newest.stem
                        _last_result["generated_blog"] = True
            asyncio.run_coroutine_threadsafe(
                queue.put("__DONE__" if ok else "__ERROR__"), loop
            )

        try:
            import yaml
            from generate import call_claude_api, run_generate
            from image_selector import select_images
            from blog_generator import (
                render_blog_post, save_blog_post, update_blog_html,
                get_related_posts, count_words_in_html, extract_excerpt,
            )
            from carousel_generator import generate_carousel as gen_carousel

            config_path = TOOLS_DIR / "config.yaml"
            with open(config_path, encoding="utf-8") as f:
                config = yaml.safe_load(f)

            model      = config["api"]["model"]
            max_tokens = config["api"]["max_tokens"]
            images_dir = str(REPO_ROOT / config["site"]["images_dir"])
            blog_dir   = str(REPO_ROOT / config["site"]["blog_dir"])
            blog_listing = str(REPO_ROOT / config["site"]["blog_listing"])
            blog_url_base = config["site"]["blog_url"]
            today = date.today()

            if generate_blog and generate_carousel:
                # Full run (both)
                args = SimpleNamespace(
                    topic=topic, blog_only=False, carousel_only=False,
                    post=None, category=None, hero_image=None,
                )
                run_generate(args)

            elif generate_blog:
                # Blog only
                args = SimpleNamespace(
                    topic=topic, blog_only=True, carousel_only=False,
                    post=None, category=None, hero_image=None,
                )
                run_generate(args)

            elif generate_carousel:
                # Carousel only (from topic — Claude generates slides, no blog saved)
                print("\n[1/3] Pozivam Claude API za generisanje sadržaja...")
                post_data = call_claude_api(topic, model, max_tokens)

                print("\n[2/3] Biram slike...")
                images = select_images(images_dir, blog_dir, post_data["category_slug"])
                print(f"      Carousel slike: {', '.join('images/' + i for i in images['carousel'])}")

                print(f"\n[3/3] Generišem Instagram carousel ({len(post_data['carousel_slides'])} slajdova)...")
                blog_url = f"{blog_url_base}/{post_data['slug']}.html"
                out_dir = gen_carousel(
                    slug=post_data["slug"],
                    carousel_slides=post_data["carousel_slides"],
                    carousel_images=images["carousel"],
                    instagram_caption=post_data.get("instagram_caption", ""),
                    repo_root=str(REPO_ROOT),
                    blog_url=blog_url,
                )
                print(f"\n      Saved: {out_dir.relative_to(REPO_ROOT)}/")
                print("\nGotovo!")

            done(ok=True)

        except SystemExit:
            done(ok=False)
        except Exception as exc:
            import traceback
            sys.stdout._orig.write(traceback.format_exc())
            asyncio.run_coroutine_threadsafe(queue.put(f"GREŠKA: {exc}"), loop)
            done(ok=False)
        finally:
            sys.stdout = old_stdout


# ---------------------------------------------------------------------------
# API endpoints
# ---------------------------------------------------------------------------

@app.post("/generate")
async def generate(req: GenerateRequest):
    import uuid
    job_id = str(uuid.uuid4())
    queue: asyncio.Queue = asyncio.Queue()
    _jobs[job_id] = queue

    loop = asyncio.get_event_loop()
    threading.Thread(
        target=_generation_thread,
        args=(req.topic, req.generate_blog, req.generate_carousel, queue, loop, req.api_key),
        daemon=True,
    ).start()

    return {"job_id": job_id}


async def _sse_generator(queue: asyncio.Queue):
    """Yield SSE-formatted lines from the queue, with heartbeat."""
    while True:
        try:
            msg = await asyncio.wait_for(queue.get(), timeout=20)
        except asyncio.TimeoutError:
            yield ": heartbeat\n\n"
            continue

        if msg in ("__DONE__", "__ERROR__"):
            yield f"data: {msg}\n\n"
            break
        else:
            # Escape newlines inside the data value
            safe = msg.replace("\n", " ")
            yield f"data: {safe}\n\n"


@app.get("/stream/{job_id}")
async def stream(job_id: str):
    if job_id not in _jobs:
        return JSONResponse({"error": "Job not found"}, status_code=404)
    return StreamingResponse(
        _sse_generator(_jobs[job_id]),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.get("/last-output")
async def last_output():
    """Return slug + PNG list of the most recently generated carousel."""
    out_root = TOOLS_DIR / "output"
    if not out_root.exists():
        return JSONResponse({"slug": None, "files": [], "caption": ""})

    dirs = [d for d in out_root.iterdir() if d.is_dir()]
    if not dirs:
        return JSONResponse({"slug": None, "files": [], "caption": ""})

    latest = max(dirs, key=lambda d: d.stat().st_mtime)
    pngs = sorted(f.name for f in latest.iterdir() if f.suffix == ".png")
    caption = ""
    cap_file = latest / "caption.txt"
    if cap_file.exists():
        caption = cap_file.read_text(encoding="utf-8")

    return JSONResponse({
        "slug": latest.name,
        "files": pngs,
        "caption": caption,
        "blog_slug": _last_result.get("slug"),
    })


@app.get("/image/{slug}/{filename}")
async def serve_image(slug: str, filename: str):
    img_path = TOOLS_DIR / "output" / slug / filename
    if not img_path.exists():
        return JSONResponse({"error": "Not found"}, status_code=404)
    return FileResponse(str(img_path))


@app.get("/last-blog")
async def last_blog():
    return JSONResponse(_last_result)


@app.get("/has-key")
async def has_key():
    return {"ok": bool(os.environ.get("ANTHROPIC_API_KEY"))}


@app.get("/")
async def index():
    html_path = TOOLS_DIR / "gui" / "index.html"
    return HTMLResponse(html_path.read_text(encoding="utf-8"))


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("Angelic Photo Generator — Web GUI")
    print("Otvori: http://localhost:8080")
    print("Zaustavi: Ctrl+C\n")
    uvicorn.run("app:app", host="127.0.0.1", port=8080, log_level="warning",
                reload=True, reload_dirs=[str(TOOLS_DIR)])
