#!/usr/bin/env python3
"""
generate.py - Main CLI entry point for Angelic Photo blog + carousel automation

Usage:
    python tools/generate.py --topic "kako odabrati lokaciju za porodično fotografisanje"
    python tools/generate.py --topic "..." --blog-only
    python tools/generate.py --carousel-only --post blog/existing-post.html
    python tools/generate.py --topic "..." --category "bebe"
    python tools/generate.py --topic "..." --hero-image "images/trudnica5.jpg"
"""

import argparse
import json
import os
import sys
from datetime import date
from pathlib import Path

import yaml

# Ensure tools/ is on path when run from repo root
TOOLS_DIR = Path(__file__).parent
REPO_ROOT = TOOLS_DIR.parent
sys.path.insert(0, str(TOOLS_DIR))

def _import_tools():
    """Import tools modules fresh (avoids stale module cache in long-running server)."""
    import importlib
    import image_selector, blog_generator, carousel_generator
    importlib.reload(image_selector)
    importlib.reload(blog_generator)
    importlib.reload(carousel_generator)
    return image_selector, blog_generator, carousel_generator


def load_config() -> dict:
    config_path = TOOLS_DIR / 'config.yaml'
    with open(config_path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)


BLOG_SYSTEM_PROMPT = """Ti si Anđela, profesionalni fotograf iz Pančeva. Pišeš blog post za svoj sajt angelicphoto.rs.

PRAVILA PISANJA:
- Piši u prvom licu, toplo i pristupačno, ali profesionalno
- Koristi "vi" formu kada se obraćaš čitaocima
- Piši prirodnim srpskim jezikom (ekavica), ne prevedenim sa engleskog
- Tehničke fotografske termine piši na srpskom gde je moguće, ali "photo session", "golden hour", "newborn", "look" i slične ustaljene termine ostavi na engleskom
- Svaki post mora imati praktičnu vrednost za čitaoca (saveti, koraci, informacije)
- Uključi lično iskustvo i anegdote gde je prirodno
- Svaki post mora imati poziv na akciju na kraju (zakazivanje termina)
- Post treba da bude 800 do 1500 reči
- Kreiraj 4 do 6 FAQ pitanja sa odgovorima relevantnim za temu
- Predloži jedan blockquote citat u prvom licu koji deluje kao lični savet

ZABRANJENO:
- NIKAKO ne koristi crtu (dash) ni dugu (—) ni kratku (–) ni srednju (-) kao interpunkciju u rečenicama
- Umesto crte koristi zarez, tačku, ili preformuliši rečenicu
- Opsege piši rečima: "od 28. do 36. nedelje", NE "28-36"
- Ne pisati hrvatske reči ni izraze, samo srpski ekavica
- Ne koristiti anglicizme sa društvenih mreža: "bio", "link u biju", "feed", "story", "reel"
- NIKAKO ne pisati "link u biju" niti "link u opisu profila". Za zakazivanje navedi da je moguće: Instagram DM (@angelic__photo), poziv/Viber/WhatsApp (+381 66 670 2000), SMS/poruka, ili kontakt forma na sajtu. Kome kako više odgovara.

SRPSKI PRAVOPIS I GRAMATIKA (obavezno):
- Uz brojeve 5 i više koristi genitiv množine: "ovih 5 grešaka", "pet saveta", NE "ove 5 grešaka"
- "nijedan", "nijedna", "nijedno" piši KAO JEDNU REČ, nikako odvojeno
- Bljeskavica je hrvatska reč. Srpski: "blica" ili "fleš". Direktno/bočno/frontalno osvetljenje opisuj kao "neadekvatno osvetljenje" ili "loše osvetljenje", bez tehničkih smernih termina
- Zamenica "koji/koja/koje" mora da se slaže u rodu i broju sa imenicom na koju se odnosi
- Glagolski oblici moraju da se slažu sa subjektom: "fotografije koje privlače", NE "fotografije koji privlači"
- Ne pisati "ukoliko" već "ako"
- Ne pisati "kako bi" već "da bi" ili reforumulisati rečenicu
- Interpunkcija: zarez pre "koji/koja/što" u zavisnoj rečenici

LOKACIJA I KONTEKST:
- Anđela dolazi na adresu klijenata (Pančevo, Beograd, Novi Sad, cela Srbija)
- Nudi: fotografisanje trudnica, beba, porodica, venčanja, krštenja, rođendana, biznis portrete, proizvode, modeling
- Sajt: angelicphoto.rs
- Instagram: @angelic__photo
- Kontakt: +381 66 670 2000

SEO ZAHTEVI:
- Prirodno uključi ciljani keyword 3 do 5 puta u tekstu
- H2 naslovi treba da budu deskriptivni i da sadrže relevantne pojmove
- Meta description: 150 do 160 karaktera, uključi keyword i poziv na akciju
- Predloži slug za URL (latinica, bez dijakritika, sa crticama)"""

BLOG_TOOL = {
    "name": "create_blog_post",
    "description": "Kreira blog post sa svim potrebnim poljima",
    "input_schema": {
        "type": "object",
        "properties": {
            "slug": {"type": "string", "description": "URL slug bez dijakritika, sa crticama"},
            "title": {"type": "string", "description": "Naslov blog posta (H1)"},
            "meta_title": {"type": "string", "description": "SEO Title do 60 karaktera"},
            "meta_description": {"type": "string", "description": "Meta opis 150-160 karaktera"},
            "category": {"type": "string", "enum": [
                "Trudnice", "Fotografisanje beba", "Porodično fotografisanje",
                "Venčanja", "Krštenja", "Rođendani", "Biznis portreti",
                "Proizvodi", "Modeling", "Saveti"
            ]},
            "category_slug": {"type": "string", "enum": [
                "trudnice", "bebe", "porodica", "vencanja", "krstenja",
                "rodjendani", "biznis", "proizvodi", "modeling", "saveti"
            ]},
            "reading_time": {"type": "integer"},
            "body_html": {"type": "string", "description": "Kompletan HTML sadržaj članka"},
            "blockquote": {"type": "string", "description": "Lični citat Anđele"},
            "faq": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "question": {"type": "string"},
                        "answer": {"type": "string"}
                    },
                    "required": ["question", "answer"]
                }
            },
            "instagram_caption": {"type": "string", "description": "Caption za Instagram sa hashtagovima"},
            "carousel_slides": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "type": {"type": "string", "enum": ["cover", "text", "photo", "cta"]},
                        "headline": {"type": "string"},
                        "subtitle": {"type": "string"},
                        "body": {"type": "string"},
                        "tip_number": {"type": "integer"}
                    },
                    "required": ["type", "headline"]
                }
            }
        },
        "required": ["slug", "title", "meta_title", "meta_description", "category",
                     "category_slug", "reading_time", "body_html", "blockquote",
                     "faq", "instagram_caption", "carousel_slides"]
    }
}


def call_claude_api(topic: str, model: str, max_tokens: int) -> dict:
    """Call Anthropic API using tool use (guaranteed valid JSON)."""
    try:
        import anthropic
    except ImportError:
        print("ERROR: anthropic package not installed. Run: pip install anthropic")
        sys.exit(1)

    api_key = os.environ.get('ANTHROPIC_API_KEY')
    if not api_key:
        print("ERROR: ANTHROPIC_API_KEY environment variable not set.")
        sys.exit(1)

    client = anthropic.Anthropic(api_key=api_key)

    print(f"      Model: {model}")
    print(f"      Topic: {topic}")

    message = client.messages.create(
        model=model,
        max_tokens=max_tokens,
        system=BLOG_SYSTEM_PROMPT,
        tools=[BLOG_TOOL],
        tool_choice={"type": "tool", "name": "create_blog_post"},
        messages=[{"role": "user", "content": f'Napiši blog post na temu: "{topic}"'}]
    )

    # tool_use block — input is already a parsed dict, no json.loads needed
    tool_block = next((b for b in message.content if b.type == "tool_use"), None)
    if not tool_block:
        print("ERROR: Claude did not return a tool_use block.")
        sys.exit(1)

    return tool_block.input


CAROUSEL_SYSTEM_PROMPT = """Ti si Anđela, profesionalni fotograf iz Pančeva. Na osnovu teksta blog posta kreiraj sadržaj za Instagram carousel i caption.

PRAVILA:
- Carousel treba da ima 6-8 slajdova koji su zanimljivi i navode ljude da listaju dalje
- Svaki tekst-slajd treba biti kratak, udarni, praktičan savet
- Piši ISKLJUČIVO srpskim jezikom, ekavica. NIKAKO ne koristiti hrvatske reči ni izraze.
- ZABRANJENI anglicizmi i socijalne mreže termini: ne pisati "bio", "link u biju", "feed", "story", "reel", "post" kao imenicu
- NIKAKO ne pisati "link u biju" niti "link u opisu profila". Za zakazivanje navedi da je moguće: Instagram DM (@angelic__photo), poziv/Viber/WhatsApp (+381 66 670 2000), SMS/poruka, ili kontakt forma na sajtu. Kome kako više odgovara.
- NIKAKO ne koristi crtu (dash) ni dugu (—) ni kratku (–) ni srednju (-) kao interpunkciju
- Opsege piši rečima: "od 28. do 36. nedelje", NE "28-36"
- Cover headline mora biti hook koji zaustavlja scrollovanje
- CTA slide poziva na zakazivanje termina. Body tekst treba da kaže da je moguće zakazati putem Instagram DM, poziva/Vibera/WhatsAppa, SMS poruke ili kontakt forme na sajtu.
- Uz brojeve 5 i više: genitiv množine, "ovih 5 grešaka" NE "ove 5 grešaka"
- "nijedan/nijedna/nijedno" piši KAO JEDNU REČ
- Bljeskavica je hrvatska reč. Srpski: "blica" ili "fleš". Osvetljenje opisuj kao "neadekvatno" ili "loše"
- Gramatičko slaganje roda, broja i padeža mora biti ispravno u svakoj rečenici
- Tvorba reči: prefiks "ne-" dodaje se na CELU reč: "neuredan" NE "neredan\""""

CAROUSEL_TOOL = {
    "name": "create_carousel",
    "description": "Kreira Instagram carousel slajdove i caption",
    "input_schema": {
        "type": "object",
        "properties": {
            "instagram_caption": {"type": "string", "description": "Caption za Instagram sa hashtagovima, do 2200 karaktera"},
            "carousel_slides": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "type": {"type": "string", "enum": ["cover", "text", "photo", "cta"]},
                        "headline": {"type": "string"},
                        "subtitle": {"type": "string"},
                        "body": {"type": "string"},
                        "tip_number": {"type": "integer"}
                    },
                    "required": ["type", "headline"]
                }
            }
        },
        "required": ["instagram_caption", "carousel_slides"]
    }
}


def call_claude_for_carousel(post_content: str, title: str, model: str, max_tokens: int) -> dict:
    """Call Claude API using tool use to generate carousel slides + instagram caption."""
    try:
        import anthropic
    except ImportError:
        print("ERROR: anthropic package not installed.")
        sys.exit(1)

    api_key = os.environ.get('ANTHROPIC_API_KEY')
    if not api_key:
        print("ERROR: ANTHROPIC_API_KEY environment variable not set.")
        sys.exit(1)

    client = anthropic.Anthropic(api_key=api_key)

    user_prompt = f"Na osnovu ovog blog posta, napravi Instagram carousel i caption:\n\nNaslov: {title}\n\n{post_content[:3000]}"

    message = client.messages.create(
        model=model,
        max_tokens=max_tokens,
        system=CAROUSEL_SYSTEM_PROMPT,
        tools=[CAROUSEL_TOOL],
        tool_choice={"type": "tool", "name": "create_carousel"},
        messages=[{"role": "user", "content": user_prompt}]
    )

    tool_block = next((b for b in message.content if b.type == "tool_use"), None)
    if not tool_block:
        print("ERROR: Claude did not return a tool_use block.")
        sys.exit(1)

    return tool_block.input


def load_post_data_from_html(post_path: str, model: str = None, max_tokens: int = 2048) -> dict:
    """Load post metadata from existing HTML and call Claude to generate carousel slides."""
    from bs4 import BeautifulSoup
    import re

    path = Path(post_path)
    if not path.exists():
        print(f"ERROR: Post file not found: {post_path}")
        sys.exit(1)

    content = path.read_text(encoding='utf-8')
    soup = BeautifulSoup(content, 'html.parser')

    slug = path.stem
    h1 = soup.find('h1', class_='blog-post-hero__title')
    title = h1.get_text(strip=True) if h1 else slug

    cat_span = soup.find('span', class_='blog-post-hero__category')
    category = cat_span.get_text(strip=True) if cat_span else 'Saveti'

    cat_map = {
        'trudnice': 'trudnice',
        'fotografisanje beba': 'bebe',
        'porodično fotografisanje': 'porodica',
        'venčanja': 'vencanja',
        'krštenja': 'krstenja',
        'rođendani': 'rodjendani',
        'biznis portreti': 'biznis',
        'proizvodi': 'proizvodi',
        'modeling': 'modeling',
    }
    category_slug = cat_map.get(category.lower(), 'saveti')

    hero_img = soup.find('img', class_='blog-post-hero__bg-img')
    hero_image = ''
    if hero_img:
        src = hero_img.get('src', '')
        hero_image = re.sub(r'^(\.\./)?images/', '', src)

    # Extract plain text from article for Claude
    article = soup.find('article', class_='blog-article')
    article_text = article.get_text(separator='\n', strip=True) if article else ''

    # Call Claude to generate real carousel slides
    print("      Calling Claude API to generate carousel slides...")
    claude_data = call_claude_for_carousel(article_text, title, model, max_tokens)

    return {
        'slug': slug,
        'title': title,
        'category': category,
        'category_slug': category_slug,
        'meta_description': '',
        'reading_time': 4,
        'carousel_slides': claude_data.get('carousel_slides', []),
        'instagram_caption': claude_data.get('instagram_caption', ''),
        '_hero_image': hero_image,
    }


def print_section(step: int, total: int, label: str):
    print(f"\n[{step}/{total}] {label}")


def run_generate(args):
    image_selector_mod, blog_generator_mod, carousel_generator_mod = _import_tools()
    select_images = image_selector_mod.select_images
    render_blog_post = blog_generator_mod.render_blog_post
    save_blog_post = blog_generator_mod.save_blog_post
    update_blog_html = blog_generator_mod.update_blog_html
    get_related_posts = blog_generator_mod.get_related_posts
    count_words_in_html = blog_generator_mod.count_words_in_html
    extract_excerpt = blog_generator_mod.extract_excerpt
    generate_carousel = carousel_generator_mod.generate_carousel

    config = load_config()

    model = config['api']['model']
    max_tokens = config['api']['max_tokens']
    images_dir = str(REPO_ROOT / config['site']['images_dir'])
    blog_dir = str(REPO_ROOT / config['site']['blog_dir'])
    blog_listing = str(REPO_ROOT / config['site']['blog_listing'])
    carousel_output_dir = str(REPO_ROOT / config['carousel']['output_dir'])

    today = date.today()

    # Determine mode
    blog_only = args.blog_only
    carousel_only = args.carousel_only

    total_steps = 5
    if blog_only:
        total_steps = 4
    elif carousel_only:
        total_steps = 3

    post_data = None
    hero_image = None
    images = None

    # --- CAROUSEL ONLY MODE ---
    if carousel_only:
        if not args.post:
            print("ERROR: --carousel-only requires --post <path>")
            sys.exit(1)

        print_section(1, total_steps, "Loading existing post + generating carousel with Claude API...")
        post_data = load_post_data_from_html(args.post, model=model, max_tokens=max_tokens)
        hero_image = post_data.get('_hero_image', '')
        slug = post_data['slug']
        category_slug = post_data.get('category_slug', 'saveti')

        print_section(2, total_steps, "Auto-selecting images for carousel...")
        hero_override = args.hero_image or (str(REPO_ROOT / 'images' / hero_image) if hero_image else None)
        images = select_images(images_dir, blog_dir, category_slug, hero_override=hero_override)
        print(f"      Carousel images: {', '.join(images['carousel'])}")

        print_section(3, total_steps, "Generating Instagram carousel...")
        print(f"      Rendering {len(post_data['carousel_slides'])} slides at 1080x1350px...")
        blog_url = f"{config['site']['blog_url']}/{slug}.html"
        out_dir = generate_carousel(
            slug=slug,
            carousel_slides=post_data['carousel_slides'],
            carousel_images=images['carousel'],
            instagram_caption=post_data.get('instagram_caption', ''),
            repo_root=str(REPO_ROOT),
            blog_url=blog_url,
        )
        print(f"\n      Saved: {out_dir.relative_to(REPO_ROOT)}/")
        print("\nDone! Review files and commit to deploy.")
        return

    # --- NORMAL MODE (blog + optional carousel) ---
    print_section(1, total_steps, "Calling Claude API for content generation...")
    post_data = call_claude_api(args.topic, model, max_tokens)

    # Override category if provided
    if args.category:
        cat_override_map = {
            'trudnice': ('Trudnice', 'trudnice'),
            'bebe': ('Fotografisanje beba', 'bebe'),
            'porodica': ('Porodično fotografisanje', 'porodica'),
            'vencanja': ('Venčanja', 'vencanja'),
            'krstenja': ('Krštenja', 'krstenja'),
            'rodjendani': ('Rođendani', 'rodjendani'),
            'biznis': ('Biznis portreti', 'biznis'),
            'proizvodi': ('Proizvodi', 'proizvodi'),
            'modeling': ('Modeling', 'modeling'),
            'saveti': ('Saveti', 'saveti'),
        }
        if args.category in cat_override_map:
            post_data['category'], post_data['category_slug'] = cat_override_map[args.category]

    word_count = count_words_in_html(post_data['body_html'])
    print_section(2, total_steps, "Content generated successfully")
    print(f"      Title: {post_data['title']}")
    print(f"      Slug: {post_data['slug']}")
    print(f"      Category: {post_data['category']}")
    print(f"      Word count: {word_count:,}")
    print(f"      Reading time: {post_data.get('reading_time', 4)} min")

    print_section(3, total_steps, "Auto-selecting images...")
    hero_override = args.hero_image
    images = select_images(images_dir, blog_dir, post_data['category_slug'], hero_override=hero_override)
    hero_image = images['hero']
    print(f"      Category match: {post_data['category_slug']}")
    print(f"      Hero image: images/{hero_image}")
    print(f"      Inline images: {', '.join('images/' + img for img in images['inline'])}")
    print(f"      Carousel images: {', '.join('images/' + img for img in images['carousel'])}")

    print_section(4, total_steps, "Generating blog post...")
    related = get_related_posts(blog_dir, exclude_slug=post_data['slug'])
    html = render_blog_post(
        data=post_data,
        hero_image=hero_image,
        inline_images=images['inline'],
        related_posts=related,
        today=today,
        repo_root=str(REPO_ROOT),
    )

    out_path = save_blog_post(html, post_data['slug'], blog_dir)
    print(f"      Saved: {out_path.relative_to(REPO_ROOT)}")

    excerpt = extract_excerpt(post_data['body_html'])
    update_blog_html(blog_listing, post_data, hero_image, today, excerpt)

    if blog_only:
        print("\nDone! Review files and commit to deploy.")
        print(f"\nFiles created/modified:")
        print(f"  + {out_path.relative_to(REPO_ROOT)}")
        print(f"  ~ blog.html")
        return

    print_section(5, total_steps, "Generating Instagram carousel...")
    print(f"      Rendering {len(post_data['carousel_slides'])} slides at 1080x1350px...")
    blog_url = f"{config['site']['blog_url']}/{post_data['slug']}.html"
    out_dir = generate_carousel(
        slug=post_data['slug'],
        carousel_slides=post_data['carousel_slides'],
        carousel_images=images['carousel'],
        instagram_caption=post_data.get('instagram_caption', ''),
        repo_root=str(REPO_ROOT),
        blog_url=blog_url,
    )
    print(f"\n      Saved: {out_dir.relative_to(REPO_ROOT)}/")

    print("\nDone! Review files and commit to deploy.")
    print(f"\nFiles created/modified:")
    print(f"  + blog/{post_data['slug']}.html")
    print(f"  ~ blog.html")
    carousel_rel = out_dir.relative_to(REPO_ROOT)
    print(f"  + {carousel_rel}/  ({len(post_data['carousel_slides'])} slides + caption.txt)")


def main():
    parser = argparse.ArgumentParser(
        description='Angelic Photo - Blog post and Instagram carousel generator'
    )
    parser.add_argument('--topic', type=str, help='Blog post topic in Serbian')
    parser.add_argument('--blog-only', action='store_true', help='Generate blog post only (no carousel)')
    parser.add_argument('--carousel-only', action='store_true', help='Generate carousel from existing post')
    parser.add_argument('--post', type=str, help='Path to existing blog post (for --carousel-only)')
    parser.add_argument('--category', type=str,
                        help='Override category slug (trudnice|bebe|porodica|vencanja|krstenja|rodjendani|biznis|proizvodi|modeling|saveti)')
    parser.add_argument('--hero-image', type=str, help='Override hero image path (e.g. images/trudnica5.jpg)')

    args = parser.parse_args()

    if not args.carousel_only and not args.topic:
        parser.error("--topic is required unless using --carousel-only")

    run_generate(args)


if __name__ == '__main__':
    main()
