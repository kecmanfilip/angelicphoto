"""
image_selector.py - Auto image selection from images/ folder
"""

import os
import re
import random
from pathlib import Path

IMAGE_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.webp', '.JPG', '.JPEG', '.PNG', '.WEBP'}

SKIP_NAMES = {
    'logo.jpg', 'logo.png', 'favicon.svg', 'favicon.ico',
    'apple-touch-icon.png', 'icon-192.png', 'icon-512.png',
    'og-image.jpg', 'andjela.jpg', 'enterijer.jpg',
}

CATEGORY_IMAGE_MAP = {
    "trudnice": ["trudnica", "trudnic", "maternity"],
    "bebe": ["beba", "bebe", "newborn", "novorodjen"],
    "porodica": ["porodic", "family"],
    "vencanja": ["vencanj", "wedding", "svadba", "mladenci"],
    "krstenja": ["krsten", "krstenje"],
    "rodjendani": ["rodjendan", "birthday", "slavlje"],
    "biznis": ["biznis", "business", "portret", "korporativ"],
    "proizvodi": ["proizvod", "product"],
    "modeling": ["model", "fashion"],
    "saveti": [],
}


def get_all_images(images_dir: str) -> list:
    """Return all usable image filenames from the images directory."""
    images_path = Path(images_dir)
    images = []
    for f in images_path.iterdir():
        if f.is_file() and f.suffix in IMAGE_EXTENSIONS:
            if f.name.lower() not in {n.lower() for n in SKIP_NAMES}:
                images.append(f.name)
    return sorted(images)


def get_used_images(blog_dir: str) -> set:
    """Parse existing blog posts to find images already in use."""
    used = set()
    blog_path = Path(blog_dir)
    if not blog_path.exists():
        return used
    for post_file in blog_path.glob('*.html'):
        try:
            content = post_file.read_text(encoding='utf-8')
            matches = re.findall(r'\.\./images/([^\s"\'><]+)', content)
            used.update(m for m in matches if m)
        except Exception:
            pass
    return used


def match_images_for_category(all_images: list, category_slug: str) -> list:
    """Return images matching the category keywords (case-insensitive)."""
    keywords = CATEGORY_IMAGE_MAP.get(category_slug, [])
    if not keywords:
        return all_images[:]  # saveti: use any

    matched = []
    for img in all_images:
        img_lower = img.lower()
        if any(kw.lower() in img_lower for kw in keywords):
            matched.append(img)
    return matched


def select_images(images_dir: str, blog_dir: str, category_slug: str,
                  hero_override: str = None) -> dict:
    """
    Select hero + inline + carousel images for a post.

    Returns:
        {
            'hero': str,             # filename
            'inline': [str, str],    # 1-2 filenames for article body
            'carousel': [str, str, str],  # cover + 2 photo slides
        }
    """
    all_images = get_all_images(images_dir)
    if not all_images:
        raise RuntimeError(f"No images found in {images_dir}")

    used_images = get_used_images(blog_dir)
    matched = match_images_for_category(all_images, category_slug)

    if not matched:
        raise RuntimeError(
            f"Nema slika za kategoriju '{category_slug}' u folderu {images_dir}. "
            f"Dodaj slike čiji naziv sadrži jednu od reči: {CATEGORY_IMAGE_MAP.get(category_slug, [])}"
        )

    if len(matched) < 3:
        print(f"      Napomena: samo {len(matched)} slika za kategoriju '{category_slug}', slika se ponavlja.")

    def fill(base: list, n: int) -> list:
        """Fill list to n items by cycling through base. Never uses images outside base."""
        result = []
        while len(result) < n:
            result.extend(base)
        return result[:n]

    # Prefer unused, but stay strictly within matched
    unused = [img for img in matched if img not in used_images]
    pool = unused[:] if unused else matched[:]
    random.shuffle(pool)
    pool = fill(pool, 5)  # ensure enough items

    if hero_override:
        hero = os.path.basename(hero_override)
    else:
        hero = pool[0]

    # Pick remaining strictly from matched, repeating if needed
    rest = fill([img for img in matched if img != hero] or matched, 4)
    random.shuffle(rest)

    return {
        'hero': hero,
        'inline': rest[:2],
        'carousel': [hero] + rest[2:4],
    }
