"""
carousel_generator.py - Instagram carousel PNG generation via Playwright
"""

import asyncio
import base64
import io
from pathlib import Path


def detect_faces(image_path: str) -> list:
    """
    Detect face bounding boxes using OpenCV Haar cascades.
    Returns list of (x1, y1, x2, y2) tuples in original image coords.
    Returns empty list if OpenCV not available or no faces found.
    """
    try:
        import cv2
    except ImportError:
        return []

    img = cv2.imread(image_path)
    if img is None:
        return []

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Try frontal face first, then profile as fallback
    cascades = [
        cv2.data.haarcascades + 'haarcascade_frontalface_default.xml',
        cv2.data.haarcascades + 'haarcascade_profileface.xml',
    ]

    faces = []
    for cascade_path in cascades:
        cascade = cv2.CascadeClassifier(cascade_path)
        detected = cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=4, minSize=(40, 40))
        if len(detected) > 0:
            faces = [(x, y, x + w, y + h) for (x, y, w, h) in detected]
            break

    return faces


def _variance_based_left(img_pil, img_w: int, new_w: int) -> int:
    """Fallback: find best horizontal crop position by pixel variance."""
    scale = 8
    small_w = max(img_w // scale, 1)
    small_h = max(img_pil.height // scale, 1)
    small = img_pil.resize((small_w, small_h)).convert('L')
    target_small_w = max(new_w // scale, 1)

    best_left_scaled = (small_w - target_small_w) // 2
    best_score = -1
    stride = max(1, (small_w - target_small_w) // 16)

    for x in range(0, max(1, small_w - target_small_w + 1), stride):
        strip = small.crop((x, 0, min(x + target_small_w, small_w), small_h))
        pixels = list(strip.getdata())
        if not pixels:
            continue
        mean = sum(pixels) / len(pixels)
        variance = sum((p - mean) ** 2 for p in pixels) / len(pixels)
        if variance > best_score:
            best_score = variance
            best_left_scaled = x

    return best_left_scaled * scale


def smart_crop_to_base64(image_path: str, target_w: int, target_h: int) -> str:
    """
    Smart-crop image to target dimensions with face-aware cropping.

    Priority order:
    1. Face detection (OpenCV) — anchors the crop on detected faces so
       heads are never cut off.
    2. Variance-based fallback — finds the most visually interesting
       horizontal region when no faces are detected.
    3. Top-bias for portrait images — biases vertical crops towards the
       upper portion where subjects usually appear.
    """
    try:
        from PIL import Image
    except ImportError:
        return image_to_base64(image_path)

    path = Path(image_path)
    if not path.exists():
        return ''

    img = Image.open(image_path).convert('RGB')
    img_w, img_h = img.size
    target_ratio = target_w / target_h
    img_ratio = img_w / img_h

    faces = detect_faces(image_path)

    if img_ratio > target_ratio + 0.05:
        # Image wider than target — must crop left/right.
        new_w = int(img_h * target_ratio)

        if faces:
            # Center crop on the face region (all faces collectively).
            face_x1 = min(f[0] for f in faces)
            face_x2 = max(f[2] for f in faces)
            face_center_x = (face_x1 + face_x2) // 2
            # Place face center at 40% from left (slightly left of center,
            # natural for portrait compositions).
            ideal_left = face_center_x - int(new_w * 0.40)
            left = max(0, min(ideal_left, img_w - new_w))
        else:
            left = _variance_based_left(img, img_w, new_w)
            left = max(0, min(left, img_w - new_w))

        img = img.crop((left, 0, left + new_w, img_h))

    elif img_ratio < target_ratio - 0.05:
        # Image taller than target — must crop top/bottom.
        new_h = int(img_w / target_ratio)
        max_top = img_h - new_h

        if faces:
            # Ensure the topmost face head is visible.
            # Add a margin of 20% of face height above the face.
            top_face_y = min(f[1] for f in faces)
            face_h_approx = max(f[3] - f[1] for f in faces)
            margin = int(face_h_approx * 0.5)
            ideal_top = max(0, top_face_y - margin)
            top = max(0, min(ideal_top, max_top))
        else:
            top = min(max_top, img_h // 6)

        img = img.crop((0, top, img_w, top + new_h))

    img = img.resize((target_w, target_h), Image.LANCZOS)

    buf = io.BytesIO()
    img.save(buf, format='JPEG', quality=88)
    b64 = base64.b64encode(buf.getvalue()).decode('utf-8')
    return f'data:image/jpeg;base64,{b64}'


async def render_slide_to_png(html_content: str, output_path: str, width: int = 1080, height: int = 1350):
    """Render HTML slide to PNG using Playwright headless Chromium."""
    try:
        from playwright.async_api import async_playwright
    except ImportError:
        raise ImportError("playwright is not installed. Run: pip install playwright && playwright install chromium")

    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page(viewport={"width": width, "height": height})
        await page.set_content(html_content, wait_until='networkidle')
        # Extra wait for fonts
        await page.wait_for_timeout(1500)
        await page.screenshot(path=output_path, type="png")
        await browser.close()


def image_to_base64(image_path: str) -> str:
    """Convert image file to base64 data URI."""
    path = Path(image_path)
    if not path.exists():
        return ''
    suffix = path.suffix.lower()
    mime_map = {'.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.webp': 'image/webp'}
    mime = mime_map.get(suffix, 'image/jpeg')
    data = path.read_bytes()
    b64 = base64.b64encode(data).decode('utf-8')
    return f'data:{mime};base64,{b64}'


def logo_to_base64(repo_root: str) -> str:
    """Convert logo.jpg to base64 data URI."""
    logo_path = Path(repo_root) / 'images' / 'logo.jpg'
    return image_to_base64(str(logo_path))


def render_cover_slide(slide: dict, image_path: str, logo_b64: str, templates_dir: str) -> str:
    """Render cover slide HTML with smart-cropped embedded image."""
    from jinja2 import Environment, FileSystemLoader
    env = Environment(loader=FileSystemLoader(str(Path(templates_dir) / 'carousel')), autoescape=False)
    template = env.get_template('slide_cover.html')
    # Cover is full 1080×1350 — smart crop to that ratio
    image_b64 = smart_crop_to_base64(image_path, 1080, 1350)
    return template.render(
        headline=slide.get('headline', ''),
        subtitle=slide.get('subtitle', ''),
        image_b64=image_b64,
        logo_b64=logo_b64,
    )


def render_text_slide(slide: dict, logo_b64: str, templates_dir: str) -> str:
    """Render text-only slide HTML."""
    from jinja2 import Environment, FileSystemLoader
    env = Environment(loader=FileSystemLoader(str(Path(templates_dir) / 'carousel')), autoescape=False)
    template = env.get_template('slide_text.html')
    return template.render(
        headline=slide.get('headline', ''),
        body=slide.get('body', ''),
        tip_number=slide.get('tip_number', ''),
        logo_b64=logo_b64,
    )


def render_photo_slide(slide: dict, image_path: str, logo_b64: str, templates_dir: str) -> str:
    """Render photo+text split slide HTML."""
    from jinja2 import Environment, FileSystemLoader
    env = Environment(loader=FileSystemLoader(str(Path(templates_dir) / 'carousel')), autoescape=False)
    template = env.get_template('slide_photo.html')
    # Photo panel is 1080×834 (top 62% of 1350) — smart crop to that exact ratio
    image_b64 = smart_crop_to_base64(image_path, 1080, 834)
    return template.render(
        headline=slide.get('headline', ''),
        body=slide.get('body', ''),
        image_b64=image_b64,
        logo_b64=logo_b64,
    )


def render_cta_slide(slide: dict, logo_b64: str, templates_dir: str) -> str:
    """Render CTA final slide HTML."""
    from jinja2 import Environment, FileSystemLoader
    env = Environment(loader=FileSystemLoader(str(Path(templates_dir) / 'carousel')), autoescape=False)
    template = env.get_template('slide_cta.html')
    return template.render(
        headline=slide.get('headline', 'Zakažite termin'),
        body=slide.get('body', ''),
        logo_b64=logo_b64,
    )


def generate_carousel(slug: str, carousel_slides: list, carousel_images: list,
                      instagram_caption: str, repo_root: str, blog_url: str) -> Path:
    """
    Generate all carousel PNG slides and caption.txt.

    carousel_images: [cover_img_filename, photo1_filename, photo2_filename]
    Returns output directory Path.
    """
    repo_root = Path(repo_root)
    tools_dir = repo_root / 'tools'
    templates_dir = tools_dir / 'templates'
    output_dir = tools_dir / 'output' / slug
    output_dir.mkdir(parents=True, exist_ok=True)
    images_dir = repo_root / 'images'

    logo_b64 = logo_to_base64(str(repo_root))

    # Build full paths for carousel images
    def img_path(filename: str) -> str:
        return str(images_dir / filename)

    # Track which photo images to use for photo slides
    photo_images = carousel_images[1:]  # skip cover image
    photo_index = 0

    slide_files = []

    for i, slide in enumerate(carousel_slides):
        slide_type = slide.get('type', 'text')
        slide_num = str(i + 1).zfill(2)

        if slide_type == 'cover':
            cover_img = carousel_images[0] if carousel_images else ''
            html = render_cover_slide(slide, img_path(cover_img), logo_b64, str(templates_dir))
            filename = f'{slide_num}_cover.png'

        elif slide_type == 'text':
            html = render_text_slide(slide, logo_b64, str(templates_dir))
            tip_num = slide.get('tip_number', i)
            filename = f'{slide_num}_tip{tip_num}.png'

        elif slide_type == 'photo':
            if photo_index < len(photo_images):
                ph_img = photo_images[photo_index]
                photo_index += 1
            else:
                ph_img = carousel_images[0] if carousel_images else ''
            html = render_photo_slide(slide, img_path(ph_img), logo_b64, str(templates_dir))
            filename = f'{slide_num}_photo.png'

        elif slide_type == 'cta':
            html = render_cta_slide(slide, logo_b64, str(templates_dir))
            filename = f'{slide_num}_cta.png'

        else:
            continue

        out_path = output_dir / filename
        asyncio.run(render_slide_to_png(html, str(out_path)))
        slide_files.append(filename)
        print(f'        {filename}')

    # Write caption.txt
    caption_with_url = instagram_caption.strip()
    if blog_url:
        caption_with_url += f'\n\n🔗 Pročitajte više na blogu: {blog_url}'
    caption_file = output_dir / 'caption.txt'
    caption_file.write_text(caption_with_url, encoding='utf-8')
    print(f'        caption.txt')

    return output_dir
